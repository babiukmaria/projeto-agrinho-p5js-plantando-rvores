function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let temperature = 20; // Temperatura inicial
let trees = []; // Array para armazenar as árvores
let gameOver = false; // Flag para controlar o estado do jogo
let gameWon = false; // Flag para verificar se o jogo foi vencido

function setup() {
  createCanvas(800, 600);
  noStroke();
  textSize(32);
}

function draw() {
  if (gameOver) {
    // Se o jogo acabou por ganhar, exibe uma mensagem de Vitória
    background(0, 255, 0); // Cor de fundo verde (vitória)
    fill(255);
    textAlign(CENTER, CENTER);
    text("VOCÊ VENCEU!", width / 2, height / 2);
    return;
  }

  if (temperature <= 0) {
    // Se a temperatura atingir 0, o jogador ganha
    gameWon = true;
    gameOver = true;
  }

  // A cor de fundo varia com base na temperatura
  let bgColor = map(temperature, 0, 50, 0, 255);
  background(bgColor, 0, 255 - bgColor); // A cor muda de vermelho para azul conforme a temperatura aumenta ou diminui

  // Exibe a temperatura na tela
  fill(255);
  text("Temperatura: " + Math.round(temperature) + "°C", 20, 40);

  // Desenha as árvores
  for (let tree of trees) {
    tree.show();
  }

  // Aumenta a temperatura se o jogador não plantar árvores
  temperature += 0.1; // A temperatura sobe aos poucos

  // Verifica se a temperatura chegou a um ponto crítico (por exemplo, 50°C)
  if (temperature >= 50) {
    gameOver = true;
  }
}

function mousePressed() {
  if (!gameOver) {
    // Quando o usuário clicar, adiciona uma nova árvore na posição do clique
    trees.push(new Tree(mouseX, mouseY));
    // Reduz a temperatura cada vez que uma árvore é plantada
    temperature = max(0, temperature - 3); // Reduz a temperatura ao plantar uma árvore
  }
}

class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(20, 40);
  }

  show() {
    // Desenha a árvore
    fill(34, 139, 34); // Cor da árvore (verde)
    ellipse(this.x, this.y - 10, this.size, this.size); // Folhas
    fill(139, 69, 19); // Cor do tronco (marrom)
    rect(this.x - 5, this.y, 10, this.size); // Tronco
  }
}
